# Vietnam Legal Advisor — 0.69.3

Local candidate: Core Skill Router plus twelve specialist skills. Vietnamese is the default language.

## Structure

- docs/: website, support, privacy, terms and website assets.
- plugin/: manifests, assets and thirteen skills.
- tests/: 22 behavioral specifications, fixtures and evaluation records.
- scripts/: validation and packaging utilities.
- dist/: generated ZIPs, excluded from Git.
- releases/: preserved local release candidates and manifests.
- tests/runs/: version-bound test reports and evidence for all three rounds.

## Commands

Requires Python 3.10+ and Pillow:

```text
python -m pip install -r scripts/requirements.txt
python scripts/validate.py
python scripts/package.py
```

Canonical image: vietnam-legal-advisor-icon-v4.png. Packaging includes only plugin/ contents. Same-version ZIPs are replaced; preserve released archives separately.

## Status

Version 0.69.3 is frozen as a local release candidate with the exact tested ZIP. Round 3 recorded 22/22 provisional AI PASS, 109/109 pre-import static checks and 14/14 technical regression checks. See tests/runs/2026-10-21-round3/ and releases/0.69.3/RELEASE.md. tests/results.json now points to the imported round-3 evidence; prior rounds and source records are preserved. Formal acceptance remains pending: qualified legal review, current-law live cases, exact model/full telemetry and production-host verification, and final publisher-approved Terms. This is not public-release approval; nothing was uploaded or deployed.

Local metadata does not confirm current hosted release or visibility. These scripts do not upload or deploy anything.
